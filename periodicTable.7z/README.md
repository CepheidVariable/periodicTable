# periodicTable
Periodic Table (Optional Assignment)


Periodic Table

This is an optional assignment. Only work on this if you are already done with all the previous CSS assignments. Please create a periodic table that looks very similar to the image below [download the image file here](http://s3.amazonaws.com/General_V88/boomyeah/company_209/chapter_2135/handouts/chapter2135_3277_periodic-table.bmp).

Do not use tables!

Make sure you're not using unnecessary divisions. Also, validate your code before you have your mentor/instructor review your code. Some of our students have completed this assignment with less than 150 lines of code! See if you can do something similar without of course putting too many things in the same line of code. :)

Please spend no more than 4 hours on this assignment.
